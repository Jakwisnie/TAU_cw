<?php

class Stats {
	private $conn;
	
	function __construct($adres, $uzytkownik, $haslo, $baza) {
		if(!$this->conn = mysqli_connect($adres, $uzytkownik, $haslo)){
			exit('Nie udało się nawiązać połączenia z bazą danych <br />');
		}
		else {
			echo('Połączenie z bazą danych zostało nawiązane <br />');
		}
		
		if(!mysqli_select_db($this->conn, $baza)){
			exit('Nie udało się wybrać bazy danych <br />');
		}
		else {
			echo('Baza danych została wybrana <br />');
		}
	}
	
	function select($sql){
		$result = mysqli_query($this->conn, $sql);
		while($row  = mysqli_fetch_assoc($result)) {
			$dane[] = $row;
		}
		
		return $dane;
	}
	
	function insert($sql){
		if(!$result = mysqli_query($this->conn, $sql)) {
			echo('Zapytanie nieudane <br />');
		}
		else {
			echo('Zapytanie wykonane poprawnie <br />');
		}
	}
    	function delete($sql){
		if(!$result = mysqli_query($this->conn, $sql)) {
			echo('Zapytanie nieudane <br />');
		}
		else {
			echo('Zapytanie wykonane poprawnie <br />');
		}
	}
    function update($sql){
		if(!$result = mysqli_query($this->conn, $sql)) {
			echo('Zapytanie nieudane <br />');
		}
		else {
			echo('Zapytanie wykonane poprawnie <br />');
		}
	}
  
    
	
	function __destruct() {
		mysqli_close($this->conn);
	}
}