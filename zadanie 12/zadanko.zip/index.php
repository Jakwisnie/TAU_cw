<?php
include 'Stats.php';

$obiekt = new Stats('localhost', 'root', '', 'menu');

$sql = "INSERT INTO wloskie (id , nazwa , cena) VALUES (5 ,'pizza', 25)";
$asd = $obiekt->insert($sql);

$sql = "DELETE FROM wloskie WHERE id = 5";
$asd = $obiekt->delete($sql);

$sql = "UPDATE wloskie SET nazwa = 'napoleoni', cena = '30' WHERE id = '0'";
$asd = $obiekt->update($sql);

$sql = "SELECT * FROM wloskie";
$asd = $obiekt->select($sql);

echo "<pre>";
print_r($asd);
echo "</pre>";